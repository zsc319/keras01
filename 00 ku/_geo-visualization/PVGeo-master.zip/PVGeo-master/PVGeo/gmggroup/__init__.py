"""
A suite of algorithms designed for compatibilty with GMG Group projects such
as the Open Mining Format specification.
"""


from .reader import *

__displayname__ = 'GMG Group Standards'
