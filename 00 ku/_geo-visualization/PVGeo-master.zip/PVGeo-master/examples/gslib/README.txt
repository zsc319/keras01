GSLib
-----

The examples shown here are downloaded from
`Multiple-point Geostatistics stochastic modeling with training images <http://www.trainingimages.org/training-images-library.html>`_ website (which recently went down, so we migrated those data
files to another location for download).
