Featured
========

Here is a list of where *PVGeo* has been featured or used:

- `SimPEG Weekly Newsletter/Meeting: 13 November 2018 <https://mailchi.mp/0ceb7504fb7a/simpeg-meeting-nov-13>`_
- `SimPEG Blog: May 28 — 3 June 2018 <https://medium.com/simpeg/may-28-june-3-23d7f45d22de>`_
- `Awesome Open Geoscience <https://github.com/softwareunderground/awesome-open-geoscience>`_ as a `Visualization Tool <https://github.com/softwareunderground/awesome-open-geoscience#visualization>`_
