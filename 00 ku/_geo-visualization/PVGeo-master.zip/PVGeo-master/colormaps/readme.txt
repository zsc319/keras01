From: https://www.paraview.org/Wiki/Colormaps

The following files contain collections of colormaps. To use them download the file and import it using ParaView's Color Map Editor dialog. Open the editor, select Choose Preset and then Import and select the file.
