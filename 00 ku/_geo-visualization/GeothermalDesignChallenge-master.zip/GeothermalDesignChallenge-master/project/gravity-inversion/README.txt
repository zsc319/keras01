Gravity Inversion
-----------------
