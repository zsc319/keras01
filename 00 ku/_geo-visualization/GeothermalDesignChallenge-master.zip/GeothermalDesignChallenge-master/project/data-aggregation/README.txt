OMF Data Collection
-------------------
