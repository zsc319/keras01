Visual Inspection
-----------------
