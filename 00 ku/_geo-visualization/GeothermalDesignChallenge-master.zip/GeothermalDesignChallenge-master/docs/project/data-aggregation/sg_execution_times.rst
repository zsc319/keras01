
:orphan:

.. _sphx_glr_project_data-aggregation_sg_execution_times:

Computation times
=================
**01:52.638** total execution time for **project_data-aggregation** files:

- **00:46.067**: :ref:`sphx_glr_project_data-aggregation_00-surfaces.py` (``00-surfaces.py``)
- **00:44.880**: :ref:`sphx_glr_project_data-aggregation_02-temperature.py` (``02-temperature.py``)
- **00:21.019**: :ref:`sphx_glr_project_data-aggregation_01-gis.py` (``01-gis.py``)
- **00:00.671**: :ref:`sphx_glr_project_data-aggregation_03-well-proposed.py` (``03-well-proposed.py``)
