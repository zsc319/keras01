
:orphan:

.. _sphx_glr_project_visual-inspection_sg_execution_times:

Computation times
=================
**02:27.890** total execution time for **project_visual-inspection** files:

- **01:01.413**: :ref:`sphx_glr_project_visual-inspection_long-submission-figures.py` (``long-submission-figures.py``)
- **00:41.010**: :ref:`sphx_glr_project_visual-inspection_long-inspect-temperature.py` (``long-inspect-temperature.py``)
- **00:25.947**: :ref:`sphx_glr_project_visual-inspection_surface-decimation.py` (``surface-decimation.py``)
- **00:19.520**: :ref:`sphx_glr_project_visual-inspection_long-inspect-gravity.py` (``long-inspect-gravity.py``)
