
:orphan:

.. _sphx_glr_project_gravity-inversion_sg_execution_times:

Computation times
=================
**01:13.567** total execution time for **project_gravity-inversion** files:

- **00:43.860**: :ref:`sphx_glr_project_gravity-inversion_01-gravity-mesh-refine.py` (``01-gravity-mesh-refine.py``)
- **00:15.252**: :ref:`sphx_glr_project_gravity-inversion_00-inspect-gravity-data.py` (``00-inspect-gravity-data.py``)
- **00:14.455**: :ref:`sphx_glr_project_gravity-inversion_02-tile-detrend.py` (``02-tile-detrend.py``)
