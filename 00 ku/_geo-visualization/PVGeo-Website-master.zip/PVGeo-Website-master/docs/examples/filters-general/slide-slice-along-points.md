!!! info
    This example will demonstrate how to slice an input data set and use a slider bar to slide that slice along a series of points

## Overview


## ParaView Example

!!! failure "Description to come!"
    There are a lot of pages in the documentation and we are trying to fill all content as soon as possible. Stay tuned for updates to this page


<!--- TODO --->

## Python Example

!!! info "{lookup:PVGeo.filters.slicing.SlideSliceAlongPoints}"

<!---

```py
import numpy as np
import vtk
from vtk.numpy_interface import dataset_adapter as dsa
import PVGeo
from PVGeo.filters import SlideSliceAlongPoints


```

TODO --->
