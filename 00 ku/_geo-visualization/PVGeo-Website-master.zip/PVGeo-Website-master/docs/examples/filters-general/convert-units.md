!!! info
    This example will demonstrate how to convert the units of the spatial reference for a given dataset.
    Currently this only support meter <-> feet conversion but can very easily be expanded to any conversions.

## Overview


## ParaView Example

!!! failure "Description to come!"
    There are a lot of pages in the documentation and we are trying to fill all content as soon as possible. Stay tuned for updates to this page


<!--- TODO --->

## Python Example

!!! info "{lookup:PVGeo.filters.xyz.ConvertUnits}"

<!---

```py
import numpy as np
import vtk
from vtk.numpy_interface import dataset_adapter as dsa
import PVGeo
from PVGeo.filters import ConvertUnits


```

TODO --->
