!!! info
    This example will demonstrate how to separate table data based on the unique
    values of a given data array into a ``vtkMultiBlockDataSet``

## Overview


## ParaView Example

!!! failure "Description to come!"
    There are a lot of pages in the documentation and we are trying to fill all content as soon as possible. Stay tuned for updates to this page


<!--- TODO --->

## Python Example

!!! info "{lookup:PVGeo.filters.tables.SplitTableOnArray}"

<!---

```py
import numpy as np
import vtk
from vtk.numpy_interface import dataset_adapter as dsa
import PVGeo
from PVGeo.filters import SplitTableOnArray


```

TODO --->
