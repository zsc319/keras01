!!! info
    This example will demonstrate how to append a dataset's cell centers as a length 3 tuple array.

## Overview


## ParaView Example

!!! failure "Description to come!"
    There are a lot of pages in the documentation and we are trying to fill all content as soon as possible. Stay tuned for updates to this page


<!--- TODO --->

## Python Example

!!! info "{lookup:PVGeo.filters.xyz.AppendCellCenters}"

<!---

```py
import numpy as np
import vtk
from vtk.numpy_interface import dataset_adapter as dsa
import PVGeo
from PVGeo.filters import AppendCellCenters


```

TODO --->
