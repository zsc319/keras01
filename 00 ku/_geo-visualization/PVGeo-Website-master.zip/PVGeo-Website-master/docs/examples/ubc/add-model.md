!!! failure "Description to come!"
    There are a lot of pages in the documentation and we are trying to fill all content as soon as possible. Stay tuned for updates to this page

These filters allows you to choose a UBC model file (or time series of files) to append as an attribute to an already created grid of a UBC Mesh.
